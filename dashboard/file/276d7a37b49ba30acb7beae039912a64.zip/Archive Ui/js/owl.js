(function($){
"use strict";
    $(document).ready(function() {
        $('.slider-content').owlCarousel({
        animateOut: 'slideOutDown',
        animateIn: 'flipInX',
        items:1,
        margin:30,
        stagePadding:30,
        smartSpeed:450
    });
    }); 
}(jQuery))
