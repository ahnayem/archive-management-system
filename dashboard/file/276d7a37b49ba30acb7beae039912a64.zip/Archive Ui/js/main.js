/* typed js*/
(function($){
    "use strict";
    /*type js*/
    var typed = new Typed(".type", {
            strings: ["I'm Ibrahim kholil","I'm a creative UI designer","I'm aslo a backend developer","Thanks for your time out here"
                     ],
            typeSpeed: 50,
            backSpeed: 50,
            loop: true
            });
    /* Fixed Nav*/
     $(window).on('scroll',function() {    
       var scroll = $(window).scrollTop();
       if (scroll < 10) {
        $("#sticky-header").removeClass("sticky");
       }else{
        $("#sticky-header").addClass("sticky");
       }
      });
    
    /* Pre loader*/
    $(document).ready(function(){
       $(".pre-loder").fadeOut(1000); 
        /* slick nav*/
        $('.menu').slicknav(); 
    /* Skill js*/
    $('.skillbar').each(function(){
          $(this).find('.skillbar-bar').animate({
            width:jQuery(this).attr('data-percent')
          },2500);
        });
        /* smooth scroll*/
        
        $('.slide-section').click(function(e){
            var linkHref = $(this).attr('href');
            $('html,body').animate({
               scrollTop: $(linkHref).offset().top 
            },1500);
            e.preventDefault();
        });
});

    
}(jQuery));

/* Owl carousel*/
(function($){
"use strict";
    $(document).ready(function() {
        $('.owl-carousel').owlCarousel({
            stagePadding: 50,
            loop:true,
            margin:100,
            nav:true,
            touchDrag:false,
            mouseDrag:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        })
    }); 
}(jQuery))










